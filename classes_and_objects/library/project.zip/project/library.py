from typing import List
from project.user import User


class Library:
    def __init__(self):
        self.user_records: List[User] = []
        self.books_available = {}
        self.rented_books = {}

    def get_book(self, author: str, book_name: str, days_to_return: int, user: User):
        username = user.username
        if book_name in self.books_available[author]:

            # Removes the given book's name from the available books
            self.books_available[author].remove(book_name)

            # Adds the book to the user's list of books
            user.books.append(book_name)

            # Creates a new renter as a dictionary in the rented books register if it does not exist
            if username not in self.rented_books:
                self.rented_books[username] = {}

            # Adds the rented book's name to the renters register with days_to_return as a value
            self.rented_books[username][book_name] = days_to_return

            return f'{book_name} successfully rented for the next {days_to_return} days!'
        else:
            rent_duration = self.rented_books[username][book_name]
            return f'The book "{book_name}" is already rented and will be available in {rent_duration} days!'

    def return_book(self, author: str, book_name: str, user: User):
        username = user.username
        # Checks if the book exists in the user's list of books
        if book_name in user.books:
            user.books.remove(book_name)
            # Removes the book's name from the username list
            self.rented_books[username].pop(book_name)
            # Adds the book to the available books dict
            self.books_available[author].append(book_name)
        else:
            return f'{username} doesn\'t have this book in his/her records!'
