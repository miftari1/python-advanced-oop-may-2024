from project.library import Library
from project.user import User


class Registration:

    @staticmethod
    def add_user(user: User, library: Library):
        if user in library.user_records:
            return f'User with id = {user.user_id} already registered in the library!'
        else:
            library.user_records.append(user)

    @staticmethod
    def remove_user(user: User, library: Library):
        if user in library.user_records:
            library.user_records.remove(user)
        else:
            return 'We could not find such user to remove!'

    @staticmethod
    def change_username(user_id: int, new_username: str, library: Library):

        # Iterates through the user records
        for user in library.user_records:

            # If the searched user id exists in the records and username matches the new username
            if user.user_id == user_id and user.username == new_username:
                return f'Please check again the provided username - ' \
                       f'it should be different than the username used so far!'

            # If the searched user id exists in the records but username does not match the new username
            elif user.user_id == user_id and user.username != new_username:

                # Changes the username with the new username in the rented books register as well
                if user.username in library.rented_books.keys():
                    library.rented_books[new_username] = library.rented_books.pop(user.username)

                user.username = new_username
                return f'Username successfully changed to: {new_username} for user id: {user_id}'

        else:
            return f'There is no user with id = {user_id}!'