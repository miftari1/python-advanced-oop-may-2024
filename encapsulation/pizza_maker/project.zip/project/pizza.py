from project.dough import Dough
from project.topping import Topping


class Pizza:
    def __init__(self, name: str, dough: Dough, max_number_of_toppings: int):
        self.name = name
        self.dough = dough
        self.max_number_of_toppings = max_number_of_toppings
        self.toppings = {}

    @property
    def name(self):
        """Returns the attribute as a private one"""
        return self.__name
    
    @name.setter
    def name(self, value):
        """Safely assigns a value to the attribute"""
        if value == '':
            raise ValueError('The name cannot be an empty string')
        self.__name = value
        
    @property
    def dough(self):
        """Returns the attribute as a private one"""
        return self.__dough
    
    @dough.setter
    def dough(self, value):
        """Safely assigns a value to the attribute"""
        if value == None:
            raise ValueError('You should add dough to the pizza')
        self.__dough = value
        
    @property
    def max_number_of_toppings(self):
        """Returns the attribute as a private one"""
        return self.__max_number_of_toppings
    
    @max_number_of_toppings.setter
    def max_number_of_toppings(self, value):
        """Safely assigns a value to the attribute"""
        if value <= 0:
            raise ValueError('The maximum number of toppings cannot be less or equal to zero')
        self.__max_number_of_toppings = value

    def add_topping(self, topping: Topping):
        """Adds a topping to the toppings dictionary"""
        if len(self.toppings) == self.__max_number_of_toppings:
            raise ValueError('Not enough space for another topping')

        if topping.topping_type in self.toppings.keys():
            self.toppings[topping.topping_type] += topping.weight
        else:
            self.toppings[topping.topping_type] = topping.weight

    def calculate_total_weight(self):
        """Returns the total weight of the pizza (dough's weight and toppings' weight)"""
        total_weight = self.__dough.weight

        for topping_weight in self.toppings.values():
            total_weight += topping_weight

        return total_weight
