from typing import List, Union

from project.animal import Animal
from project.worker import Worker


class Zoo:
    def __init__(self, name: str, budget: int, animal_capacity: int, workers_capacity: int):
        self.name = name
        self.budget = budget
        self.animal_capacity = animal_capacity
        self.workers_capacity = workers_capacity
        self.animals: List[Animal] = []
        self.workers: List[Worker] = []

    @property
    def budget(self):
        return self.__budget

    @budget.setter
    def budget(self, value):
        self.__budget = value

    @property
    def animal_capacity(self):
        return self.__animal_capacity

    @animal_capacity.setter
    def animal_capacity(self, value):
        self.__animal_capacity = value

    @property
    def workers_capacity(self):
        return self.__workers_capacity

    @workers_capacity.setter
    def workers_capacity(self, value):
        self.__workers_capacity = value

    def add_animal(self, animal: Animal, price):
        if price >  self.__budget:
            return 'Not enough budget'

        elif self.__animal_capacity == len(self.animals):
            return 'Not enough space for animal'

        else:
            self.__budget -= price
            self.animals.append(animal)
            return f'{animal.name} the {animal.__class__.__name__} added to the zoo'

    def hire_worker(self, worker: Worker):
        if self.__workers_capacity > len(self.workers):
            self.workers.append(worker)
            return f'{worker.name} the {worker.__class__.__name__} hired successfully'

        else:
            return f'Not enough space for worker'

    def fire_worker(self, worker_name):
        for worker in self.workers:
            if worker.name == worker_name:
                self.workers.remove(worker)
                return f'{worker_name} fired successfully'

        else:
            return f'There is no {worker_name} in the zoo'

    def pay_workers(self):
        sum_salaries = 0
        for worker in self.workers:
            sum_salaries += worker.salary

        if self.__budget >= sum_salaries:
            self.__budget -= sum_salaries
            return f'You payed your workers. They are happy. Budget left: {self.__budget}'

        else:
            return f'You have no budget to pay your workers. They are unhappy'

    def tend_animals(self):
        sum_animal_care_cost = 0
        for animal in self.animals:
            sum_animal_care_cost += animal.money_for_care

        if self.__budget >= sum_animal_care_cost:
            self.__budget -= sum_animal_care_cost
            return f'You tended all the animals. They are happy. Budget left: {self.__budget}'

        else:
            return f'You have no budget to tend the animals. They are unhappy.'

    def profit(self, amount):
        self.__budget += amount

    def animals_status(self):
        return Zoo.__print_status(self.animals, 'Lion', 'Tiger', 'Cheetah')

    def workers_status(self):
        return Zoo.__print_status(self.workers, 'Keeper', 'Caretaker', 'Vet')

    @staticmethod
    def __print_status(lst: List[Union[Animal, Worker]], *args):
        elements = {arg: [] for arg in args}
        for obj in lst:
            elements[obj.__class__.__name__].append(repr(obj))

        result = [f'You have {len(lst)} {str(lst[0].__class__.__bases__[0].__name__).lower()}s']
        for arg in args:
            result.append(f'----- {len(elements[arg])} {arg}s:')
            result.extend(elements[arg])

        return '\n'.join(result)
