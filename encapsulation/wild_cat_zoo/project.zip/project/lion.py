from project.animal import Animal


class Lion(Animal):
    cost_for_care = 50

    def __init__(self, name, gender, age):
        super().__init__(name, gender, age, money_for_care=Lion.cost_for_care)