from typing import List
from project.product import Product


class ProductRepository:

    def __init__(self):
        self.products: List[Product] = []

    def add(self, product: Product):
        self.products.append(product)

    def find(self, product_name: str):
        for p_obj in self.products:
            if p_obj.name == product_name:
                return p_obj

    def remove(self, product_name):
        for p_obj in self.products:
            if p_obj.name == product_name:
                self.products.remove(p_obj)
                return

    def __repr__(self):

        prod_info = []
        for prod in self.products:
            current_prod_info = f'{prod.name}: {prod.quantity}'
            prod_info.append(current_prod_info)

        return '\n'.join(prod_info)