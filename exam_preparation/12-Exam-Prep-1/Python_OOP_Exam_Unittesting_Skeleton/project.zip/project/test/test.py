from project.tennis_player import TennisPlayer

from unittest import TestCase, main


class TestTennisPlayer(TestCase):
    def setUp(self) -> None:
        self.player = TennisPlayer('Name', 20, 30)

    def test_init(self):
        self.assertEqual('Name', self.player.name)
        self.assertEqual(20, self.player.age)
        self.assertEqual(30, self.player.points)
        self.assertEqual([], self.player.wins)

    def test_name_setter_if_name_len_less_than_or_equal_to_zero_raises(self):
        with self.assertRaises(ValueError) as ex:
            self.player.name = 'a'

        self.assertEqual("Name should be more than 2 symbols!", str(ex.exception))
        self.assertEqual('Name', self.player.name)

        with self.assertRaises(ValueError) as ex:
            self.player.name = 'aa'

        self.assertEqual("Name should be more than 2 symbols!", str(ex.exception))
        self.assertEqual('Name', self.player.name)

    def test_age_setter_if_age__less_than_18_raises(self):
        with self.assertRaises(ValueError) as ex:
            self.player.age = 17

        self.assertEqual("Players must be at least 18 years of age!", str(ex.exception))
        self.assertEqual(20, self.player.age)

    def test_player_add_new_win_if_tournament_not_in_wins(self):
        self.assertEqual([], self.player.wins)
        self.player.add_new_win('Rolan')
        self.assertIn('Rolan', self.player.wins)

    def test_player_add_new_win_if_tournament_in_wins_already_added(self):
        self.assertEqual([], self.player.wins)
        self.player.add_new_win('Rolan')

        result = self.player.add_new_win('Rolan')
        self.assertEqual(['Rolan'], self.player.wins)
        self.assertEqual('Rolan has been already added to the list of wins!', result)

    def test_player_less_than_method(self):
        self.player2 = TennisPlayer('Name2', 21, 40)
        result = self.player < self.player2

        self.assertEqual('Name2 is a top seeded player and he/she is better than Name', result)

        self.player2.points = 30

        result = self.player < self.player2

        self.assertEqual('Name is a better player than Name2', result)

        self.player2.points = 20

        result = self.player < self.player2

        self.assertEqual('Name is a better player than Name2', result)

    def test_player_str_method(self):
        self.player.add_new_win('Rolan')
        self.player.add_new_win('US Open')

        result = self.player.__str__()
        expected = f"Tennis Player: Name\n" \
                   f"Age: 20\n" \
                   f"Points: 30.0\n" \
                   f"Tournaments won: Rolan, US Open"

        self.assertEqual(expected, result)

if __name__ == '__main__':
    main()